import "server-only";
import { z } from "zod";
import { Prisma } from "@/app/generated/prisma/client";
const profileSchema = z.object({
  firstName: z.string().max(50),
  lastName: z.string().max(50),
  phoneNumber: z.string().max(30),
  consentAt: z.string().datetime(),
});
type Profile = z.infer<typeof profileSchema>;
import { prisma } from "./prisma";
import { hash, token, baseUrl, AppError, rateLimit } from "./security";
import { assertEmailConfigured, emailFrame, sendEmail } from "./email";

export async function requestVerification(
  name: string,
  email: string,
  profile?: Profile,
) {
  assertEmailConfigured();
  await rateLimit("verification:" + email, 1, 120);
  const current = await prisma.subscriber.findUnique({ where: { email } });
  if (current?.emailVerified && current.subscribed) return;
  const raw = token();
  const subscriber = await prisma.subscriber.upsert({
    where: { email },
    create: {
      name,
      email,
      ...(profile
        ? {
            firstName: profile.firstName,
            lastName: profile.lastName,
            phoneNumber: profile.phoneNumber,
            consentAt: new Date(profile.consentAt),
            pendingProfile: profile,
          }
        : {}),
      verificationToken: hash(raw),
      verificationExpiresAt: new Date(Date.now() + 86400000),
      unsubscribeToken: token(),
    },
    update: {
      ...(profile ? { pendingProfile: profile } : {}),
      verificationToken: hash(raw),
      verificationExpiresAt: new Date(Date.now() + 86400000),
    },
  });
  const url = `${baseUrl()}/verify?token=${raw}`;
  try {
    await sendEmail(
      email,
      "Confirm your TPAV Class Action subscription",
      emailFrame(
        "Confirm your email",
        "<p>Please confirm that you would like to receive TPAV Class Action news and updates. This link expires in 24 hours. You do not need an account or password.</p>",
        "Confirm subscription",
        url,
      ),
      `verify-${subscriber.id}-${hash(raw)}`,
    );
  } catch (error) {
    await prisma.subscriber.updateMany({
      where: { id: subscriber.id, verificationToken: hash(raw) },
      data: { verificationToken: null, verificationExpiresAt: null },
    });
    throw error;
  }
}
export async function verifySubscription(raw: string) {
  const current = await prisma.subscriber.findUnique({
    where: { verificationToken: hash(raw) },
    select: { pendingProfile: true },
  });
  const profile = profileSchema.safeParse(current?.pendingProfile);
  const result = await prisma.subscriber.updateMany({
    where: {
      verificationToken: hash(raw),
      verificationExpiresAt: { gt: new Date() },
    },
    data: {
      ...(profile.success
        ? {
            firstName: profile.data.firstName,
            lastName: profile.data.lastName,
            phoneNumber: profile.data.phoneNumber,
            name: `${profile.data.firstName} ${profile.data.lastName}`,
            consentAt: new Date(profile.data.consentAt),
          }
        : {}),
      pendingProfile: Prisma.DbNull,
      emailVerified: true,
      subscribed: true,
      verifiedAt: new Date(),
      unsubscribedAt: null,
      verificationToken: null,
      verificationExpiresAt: null,
    },
  });
  if (!result.count)
    throw new AppError(
      "This verification link is invalid, expired, or has already been used. Request a new email below.",
      410,
    );
}
export async function unsubscribe(raw: string) {
  const result = await prisma.subscriber.updateMany({
    where: { unsubscribeToken: raw },
    data: {
      subscribed: false,
      unsubscribedAt: new Date(),
      verificationToken: null,
      verificationExpiresAt: null,
    },
  });
  if (!result.count)
    throw new AppError(
      "This unsubscribe link is invalid. Please use the link in your latest email.",
      404,
    );
}
