import "server-only";
import { AppError, baseUrl } from "./security";
import { cleanHtml } from "./validation";
export function escapeHtml(v: string) {
  return v.replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
      c
      ]!,
  );
}
export function emailFrame(
  heading: string,
  content: string,
  buttonText?: string,
  buttonUrl?: string,
  unsubscribeUrl?: string,
) {
  return `<div style="background:#f2f6fd;padding:32px;font-family:Arial,sans-serif;color:#011b3e"><div style="max-width:600px;margin:auto;background:white;padding:32px;border-radius:16px"><p style="font-size:12px;letter-spacing:2px">TPAV CLASS ACTION</p><h1>${escapeHtml(heading)}</h1>${cleanHtml(content)}${buttonText && buttonUrl ? `<p><a style="background:#001c3f;color:white;padding:14px 24px;display:inline-block;border-radius:8px" href="${escapeHtml(buttonUrl)}">${escapeHtml(buttonText)}</a></p>` : ""}<hr><p style="font-size:12px">${unsubscribeUrl ? `You requested TPAV Class Action updates. <a href="${escapeHtml(unsubscribeUrl)}">Unsubscribe</a>` : `If you did not request this email, you can ignore it.`}</p><p style="font-size:12px"><a href="${baseUrl()}/privacy">Privacy</a> · TPAV Class Action</p></div></div>`;
}
export function assertEmailConfigured() {
  if (
    process.env.EMAIL_PROVIDER !== "resend" ||
    !process.env.RESEND_API_KEY ||
    !process.env.EMAIL_FROM
  )
    throw new AppError(
      "Email delivery is not configured. Please contact the site administrator.",
      503,
    );
}
export async function sendEmail(
  to: string,
  subject: string,
  html: string,
  key: string,
  unsubscribeUrl?: string,
) {
  assertEmailConfigured();
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
      "Idempotency-Key": key,
    },
    body: JSON.stringify({
      from: process.env.EMAIL_FROM,
      to: [to],
      subject,
      html,
      ...(process.env.EMAIL_REPLY_TO
        ? { reply_to: process.env.EMAIL_REPLY_TO }
        : {}),
      ...(unsubscribeUrl
        ? {
          headers: {
            "List-Unsubscribe": `<${unsubscribeUrl.replace("/unsubscribe?", "/api/unsubscribe?")}>`,
            "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
          },
        }
        : {}),
    }),
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) {
    const errorText = await response.text();

    console.error("Resend API error:", {
      status: response.status,
      response: errorText,
    });

    throw new AppError(
      `Email provider rejected the request (${response.status}).`,
      502,
    );
  }
  const data = (await response.json()) as { id: string };
  return data.id;
}
