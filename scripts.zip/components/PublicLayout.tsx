import Link from "next/link";
import SubscriptionModal from "./SubscriptionModal";
import { getSettings } from "@/lib/settings";
import { PublicHeader, BackToTop } from "./PublicChrome";
export default async function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const settings = await getSettings();
  return (
    <SubscriptionModal>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <PublicHeader />
      <main id="main">{children}</main>
      <footer className="footer-sec wrapper">
        <div className="container">
          <div className="row justify-content-between">
            <div className="col-lg-2 col-md-6 col-sm-6 col-12">
              <div className="footer-logo">
                <Link href="/">
                  <img
                    src="/assets/images/logo.png"
                    className="img-fluid"
                    alt="TPAV Class Action"
                    width={170}
                  />
                </Link>
              </div>
            </div>
            <div className="col-lg-2 col-md-6 col-sm-6 col-12">
              <div className="footer-heading">Quick links</div>
              <div className="footer-link">
                <ul>
                  <li>
                    <Link href="/authors-story">Author’s Story</Link>
                  </li>
                  <li>
                    <Link href="/updates">Updates</Link>
                  </li>
                  <li>
                    <Link href="/contact">Contact Us</Link>
                  </li>
                  <li>
                    <Link href="/unsubscribe">Unsubscribe</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-2 col-md-6 col-sm-6 col-12">
              <div className="footer-heading">Legal</div>
              <div className="footer-link">
                <ul>
                  <li>
                    <Link href="/privacy">Privacy policy</Link>
                  </li>
                  <li>
                    <Link href="/terms">Terms of Service</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6 col-12">
              <div className="footer-heading pb-3">Connect</div>
              <div className="social-link">
                <ul>
                  {[
                    ["facebook", "fb"],
                    ["instagram", "insta"],
                    ["twitter", "twitter"],
                    ["youtube", "youtube"],
                  ].map(([key, asset]) =>
                    settings[key] ? (
                      <li key={key}>
                        <a
                          href={settings[key]}
                          target="_blank"
                          rel="noopener noreferrer"
                          aria-label={key}
                        >
                          <img
                            src={`/assets/images/${asset}-icon.png`}
                            alt=""
                          />
                        </a>
                      </li>
                    ) : null,
                  )}
                </ul>
              </div>
              <Link href="/contact">Get in touch</Link>
            </div>
          </div>
        </div>
        <div className="copyright-text">
          Copyright © {new Date().getFullYear()} TPAV Class Action. Design by{" "}
          <a
            href="https://jrtechnologiesweb.com/"
            target="_blank"
            rel="noopener noreferrer"
          >
            JR Technologies Web
          </a>
        </div>
        <BackToTop />
      </footer>
    </SubscriptionModal>
  );
}
