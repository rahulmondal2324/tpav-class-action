import Link from "next/link";
export default function InnerPage({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <>
      <div className="inner-banner-sec">
        <div className="container">
          <h1 className="inner-banner-heading">{title}</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center">
              <li className="breadcrumb-item">
                <Link href="/">Home</Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                {title}
              </li>
            </ol>
          </nav>
        </div>
      </div>
      <section className="inner-sec">
        <div className="container">{children}</div>
      </section>
    </>
  );
}
