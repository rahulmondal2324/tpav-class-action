import InnerPage from "@/components/InnerPage";
import { getSettings } from "@/lib/settings";
export const metadata = { title: "Author’s Story" };
export default async function Page() {
  const settings = await getSettings();
  return (
    <InnerPage title="Author’s Story">
      <div className="content-narrow prose">
        {settings.authorStory ? (
          settings.authorStory
            .split(/\n\s*\n/)
            .map((p, i) => <p key={i}>{p}</p>)
        ) : (
          <p>The author’s story will be shared here when it is ready.</p>
        )}
      </div>
    </InnerPage>
  );
}
