import InnerPage from "@/components/InnerPage";
import { getSettings } from "@/lib/settings";
export const metadata = { title: "Contact Us" };
export default async function Page() {
  const settings = await getSettings();
  return (
    <InnerPage title="Contact Us">
      <div className="content-narrow">
        <h2>Let’s stay connected</h2>
        <p>
          For questions about the initiative or your subscription, contact the
          team.
        </p>
        {settings.contactEmail ? (
          <a className="btn-action" href={"mailto:" + settings.contactEmail}>
            {settings.contactEmail}
          </a>
        ) : (
          <p>Contact details will be published here shortly.</p>
        )}
        <p className="mt-4">
          To stop receiving updates, use the unsubscribe link in your latest
          email.
        </p>
      </div>
    </InnerPage>
  );
}
