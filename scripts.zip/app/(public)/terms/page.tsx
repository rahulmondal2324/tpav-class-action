import InnerPage from "@/components/InnerPage";
import { getSettings } from "@/lib/settings";
export const metadata = { title: "Terms of Service" };
export default async function Page() {
  const settings = await getSettings();
  return (
    <InnerPage title="Terms of Service">
      <div className="content-narrow prose">
        {settings.terms ? (
          settings.terms.split(/\n\s*\n/).map((p, i) => <p key={i}>{p}</p>)
        ) : (
          <p>
            This page is awaiting publication by the site administrator. Please
            contact the team for current information.
          </p>
        )}
      </div>
    </InnerPage>
  );
}
