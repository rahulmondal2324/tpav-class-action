import InnerPage from "@/components/InnerPage";
import { getSettings } from "@/lib/settings";
export const metadata = { title: "Privacy Policy" };
export default async function Page() {
  const settings = await getSettings();
  return (
    <InnerPage title="Privacy Policy">
      <div className="content-narrow prose">
        {settings.privacy ? (
          settings.privacy.split(/\n\s*\n/).map((p, i) => <p key={i}>{p}</p>)
        ) : (
          <p>
            This page is awaiting publication by the site administrator. Please
            contact the team for current information.
          </p>
        )}
      </div>
    </InnerPage>
  );
}
