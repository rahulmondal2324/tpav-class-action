import { assertEmailConfigured } from "@/lib/email";
import { subscribeSchema } from "@/lib/validation";
import { checkOrigin, rateLimit, requestIp } from "@/lib/security";
import { jsonBody, failure } from "@/lib/http";
import { requestVerification } from "@/lib/subscribers";
export async function POST(request: Request) {
  try {
    checkOrigin(request);

    const body = await jsonBody(request);

    console.log("SUBSCRIBE BODY:", body);

    const data = subscribeSchema.parse(body);

    console.log("SUBSCRIBE VALIDATED:", data);

    assertEmailConfigured();

    console.log("EMAIL CONFIG OK");

    await rateLimit(
      "subscribe-ip:" + requestIp(request),
      20,
      3600,
    );

    console.log("RATE LIMIT OK");

    await requestVerification(
      `${data.firstName} ${data.lastName}`,
      data.email,
      {
        firstName: data.firstName,
        lastName: data.lastName,
        phoneNumber: data.phoneNumber,
        consentAt: new Date().toISOString(),
      },
    );

    console.log("VERIFICATION REQUEST COMPLETE");

    return Response.json({
      message:
        "If confirmation is needed, an email is on its way. Please check your inbox and spam folder.",
    });
  } catch (error) {
    console.error("SUBSCRIBE API ERROR:");
    console.error(error);

    if (error instanceof Error) {
      console.error("NAME:", error.name);
      console.error("MESSAGE:", error.message);
      console.error("STACK:", error.stack);
    }
    return failure(error);
  }
}
